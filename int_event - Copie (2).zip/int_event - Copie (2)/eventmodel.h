#ifndef EVENTMODEL_H
#define EVENTMODEL_H
#include <QSqlQueryModel>
#include <QPixmap>

class eventmodel : public QSqlQueryModel
        {
        public:
        public:
            void refresh();
            void refresh1();
        };


#endif // EVENTMODEL_H
